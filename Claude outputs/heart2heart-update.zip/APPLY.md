# Apply these changes

Unzip over the project root, keeping the folder structure. Then:

## 1. Delete these — they are gone from the build and must be removed by hand

    src/app/api/                              (the whole folder — all 5 route handlers)
    src/components/layout/quick-exit.tsx      (orphaned since the quick exit was removed)
    public/fonts/fraunces-600.woff2           (replaced by fraunces-display + fraunces-text)

Nothing imports any of them, but leaving `src/app/api` in place will put the
routes back into the build.

## 2. Reinstall and rebuild from clean

    rm -rf node_modules .next
    npm ci
    npm run build

`package-lock.json` is included and has a postcss security fix in it, so `npm ci`
rather than `npm install`.

## 3. If /en/about still fails to prerender

It builds cleanly here from a clean `npm ci`, on Node 22, so the difference is
in your environment or your working tree. To get the real message instead of the
digest, run the build locally — the full stack is printed above the digest line
in a local build, and only omitted in the deployed one:

    npm run build 2>&1 | tee build.log

Send me `build.log` and I can fix it directly.

Two things worth ruling out first:
- Node version. `.nvmrc` and `engines` now pin 20.9+; set the same on your
  deployment platform. A build that works locally and fails on deploy is
  usually two different Node versions.
- A dev server left running during the last file drop. Stop it, `rm -rf .next`.

## What changed

- **No API.** `src/app/api` deleted. Every form now resolves locally through
  `src/lib/demo.ts` — four functions shaped like the endpoints that replace
  them. Nothing is recorded. Sign-in uses a Server Action so the session cookie
  stays httpOnly.
- **Cover art** on articles and video thumbnails, generated into
  `public/covers/` by `scripts/covers.py` (reads the real slugs out of the
  fixtures, so it cannot drift).
- **English and Hausa untouched.** `[locale]` routing, both message files and
  the language switcher all stay exactly as they were.
- Node pinned, postcss advisory fixed, `npm run test:hydration` added.
